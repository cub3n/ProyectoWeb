﻿using Ejemplo.Models;
using Ejemplo.Models.ViewsEjemplos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ejemplo.Controllers
{
    public class EjemploController : Controller
    {
        // GET: Ejemplo
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult MostrarEjemplo()
        {
            List<MostrarEjemplo> aux = new List<MostrarEjemplo>();
            using (DISTRIBUIDORAEntities db = new DISTRIBUIDORAEntities())
            {
                foreach (PRODUCTOS x in db.PRODUCTOS)
                {
                    MostrarEjemplo llenar = new MostrarEjemplo();
                    llenar.IdProducto = x.IdProducto;
                    llenar.NombreProducto = x.NombreProducto;
                    llenar.NombreCliente = db.CLIENTES.Find(x.IdCliente).Nombre;
                    llenar.UnidadesCompradas = x.Unidades;
                    llenar.PrecioProducto = x.Costo;
                    llenar.SubTotal = llenar.UnidadesCompradas * llenar.PrecioProducto;
                    llenar.Total = llenar.SubTotal - db.CLIENTES.Find(x.IdCliente).DESCUENTO;
                    aux.Add(llenar);
                }
            }
            return View(aux);
        }

        // GET: Ejemplo/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Ejemplo/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Ejemplo/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Ejemplo/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Ejemplo/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Ejemplo/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Ejemplo/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
