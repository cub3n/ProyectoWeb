﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ejemplo.Models.ViewsEjemplos
{
    public class MostrarEjemplo
    {
        public int IdProducto { get; set; }
        public string NombreProducto { get; set; }
        public string NombreCliente { get; set; }
        public int? UnidadesCompradas { get; set; }
        public decimal? PrecioProducto { get; set; }
        public decimal? SubTotal { get; set; }
        public decimal? Total { get; set; }
    }
}